# Mac Launcher (Android)

A macOS-style home screen for Android: lock screen with password, Launchpad app drawer that lists every app on the phone,
windows, wallpapers, themes, Safari, App Store, Word/Excel/PowerPoint-style apps and games.

## Build the APK without a computer (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the repository's **Actions** tab, run **Build APK**, then download `MacLauncher-apk` when it finishes.
4. Unzip it, install `app-debug.apk` (allow "install unknown apps" if asked).

## Build with Android Studio
Open this folder in Android Studio and choose Build > Build APK.

## Use it
Press Home, pick **Mac Launcher**, then **Always**. Android's own lock screen stays on top of this one.

## Open phone apps in windows
Phone apps open in a window only if your phone supports freeform windows:
Settings > Developer options > turn on **Enable freeform windows** and **Force activities to be resizable**, then restart.
Otherwise they open full screen as normal.
