package com.example.maclauncher;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private WebView web;

    // lock the launcher whenever the screen turns off
    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            js("window.lockNow && window.lockNow()");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // wallpapers, theme, password hash, documents are saved here

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff, f);
    }

    @Override
    public void onBackPressed() {
        // a launcher never exits: Back closes Launchpad or the front window instead
        js("window.goBack && window.goBack()");
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(screenOff); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void js(final String code) {
        if (web != null) web.post(() -> web.evaluateJavascript(code, null));
    }

    private String iconData(Drawable d) {
        int size = 72;
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, size, size);
        d.draw(new Canvas(bm));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    /** Methods the web page can call as window.Android.* */
    private class Bridge {

        @JavascriptInterface
        public String getApps() {
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
                Collections.sort(list, new ResolveInfo.DisplayNameComparator(pm));
                JSONArray out = new JSONArray();
                for (ResolveInfo r : list) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", String.valueOf(r.loadLabel(pm)));
                    o.put("pkg", pkg);
                    o.put("icon", iconData(r.loadIcon(pm)));
                    out.put(o);
                }
                return out.toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        /** Opens an installed app. If the phone allows freeform windows it opens in a window of this size. */
        @JavascriptInterface
        public void launch(final String pkg, final int x, final int y, final int w, final int h) {
            runOnUiThread(() -> {
                try {
                    Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i == null) return;
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    Bundle opts = null;
                    if (w > 0 && h > 0) {
                        opts = ActivityOptions.makeBasic().setLaunchBounds(new Rect(x, y, x + w, y + h)).toBundle();
                    }
                    startActivity(i, opts);
                } catch (Exception ignored) { }
            });
        }
    }
}
